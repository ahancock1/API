﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;


/// <summary>
/// Summary description for httpHandler
/// </summary>
public class HttpHandler : IHttpHandler
{
    public HttpHandler()
	{
		// TODO: Add constructor logic here
	}

    public void ProcessRequest(HttpContext context)
    {
        HttpRequest request     = context.Request;

        //remove the path prefex to leave just the URI
        //string path = request.Path.Replace("/soft338/ahancock/", "");

        string[] split = request.Path.ToString().Split('/');

        switch (split[3].ToLower())
        {
            case "v1":  
                {
                    switch (split[4].ToLower())
                    {
                        case "module":      //process module URI
                            moduleHandler(context, split); 
                            break;
                        case "lecture":     //process lecture URI
                            sessionHandler(context, split); 
                            break;
                        case "practical":   //process practical URI
                            sessionHandler(context, split); 
                            break;
                        default:            //404 page not found response
                            pageNotFound(context); 
                            break;      
                    }
                    break;
                }
            case "v2":  //future development
                {                    
                    break;
                }
            default:    //404 page not found response
                {
                    pageNotFound(context);
                    break;      
                }
            
        }
    }

    public void moduleHandler(HttpContext context, string[] split)
    {
        string verb = context.Request.HttpMethod.ToUpper();
        switch (verb)
        {
            case "GET":
                if (split.Length >= 6)  //get module by module ID 
                {
                    if (split[5] != null)
                        getModuleByID(context, split);
                }
                else                    //gets all the modules
                    getAllModules(context);
                break;
            case "PUT":         updateModule(context);                  break;      //updates a module
            case "POST":        postNewModule(context);                 break;      //posts a new module
            case "DELETE":      deleteModule(context);                  break;      //deletes a module
            default:                                                    break;
        }
    }


    public void sessionHandler(HttpContext context, string[] split) //com string[]4
    {
        string verb = context.Request.HttpMethod.ToUpper();
        switch (verb)
        {
            case "GET":
                if (split.Length >= 6)
                {
                    if (split[5] != null)
                        getSessionByID(context, split);
                }
                else
                    getAllSessions(context, split);    
                break;
            case "PUT":         updateSession(context);                 break;
            case "POST":        postNewSession(context);                break;
            case "DELETE":      deleteSession(context);                 break;
            default:                                                    break;
        }
    }

    /*
    public void practicalHandler(HttpContext context)
    {
        string verb = context.Request.HttpMethod.ToUpper();
        switch (verb)
        {
            case "GET":         getAllSessions(context, "Practical");   break;
            case "PUT":         updateSession(context);                 break;
            case "POST":        postNewSession(context);                break;
            case "DELETE":      deleteSession(context);                 break;
            default:                                                    break;
        }
    }
     */

    #region Post methods
    private void postNewModule(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Module));
        Module module = (Module)jsonData.ReadObject(context.Request.InputStream);
        Int32 moduleID = DbCon.insertNewModule(module);
    }

    private void postNewSession(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Module));
        Session session = (Session)jsonData.ReadObject(context.Request.InputStream);
        Int32 sessionID = DbCon.insertNewSession(session);
    }
    #endregion

    #region Put methods
    private void updateModule(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Module));
        Module module = (Module)jsonData.ReadObject(context.Request.InputStream);
        Int32 moduleID = DbCon.updateModule(module);
        HttpResponse response = context.Response;
    }

    private void updateSession(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Module));
        Session session = (Session)jsonData.ReadObject(context.Request.InputStream);
        Int32 sessionID = DbCon.updateSession(session);
        HttpResponse response = context.Response;
    }
    #endregion

    #region Delete methods
    private void deleteModule(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Module));
        Module module = (Module)jsonData.ReadObject(context.Request.InputStream);
        Int32 moduleID = DbCon.deleteModule(module);
    }

    private void deleteSession(HttpContext context)
    {
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(Session));
        Session session = (Session)jsonData.ReadObject(context.Request.InputStream);
        Int32 sessionID = DbCon.deleteSession(session);
    }
    #endregion

    #region Get all methods
    private void getAllModules(HttpContext context)
    {
        Stream outputStream = context.Response.OutputStream;
        context.Response.ContentType = "application/json";

        //loops through all the module entries and outputs them in json format
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<Module>));
        IEnumerable<Module> modules = DbCon.getAllmodules();
        jsonData.WriteObject(outputStream, modules);
    }

    private void getAllSessions(HttpContext context, string[] split)
    {
        Stream outputStream = context.Response.OutputStream;
        context.Response.ContentType = "application/json";

        //loops through all the module entries and outputs them in json format
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<Session>));
        IEnumerable<Session> session = DbCon.getAllSessions(split[4]);

        jsonData.WriteObject(outputStream, session);
    }

    private void getModuleByID(HttpContext context, string[] split)
    {
        Stream outputStream = context.Response.OutputStream;
        context.Response.ContentType = "application/json";

        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<Module>));
        IEnumerable<Module> modules = DbCon.getModuleByName(split[5]);
        jsonData.WriteObject(outputStream, modules);
    }

    private void getSessionByID(HttpContext context, string[] split)
    {
        Stream outputStream = context.Response.OutputStream;
        context.Response.ContentType = "application/json";

        //loops through all the module entries and outputs them in json format
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<Session>));
        IEnumerable<Session> session = DbCon.getSessionByName(split[5], split[4]);

        jsonData.WriteObject(outputStream, session);
    }
    #endregion 

    public bool IsReusable
    {
        // To enable pooling, return true here.
        // This keeps the handler in memory.
        get { return true; }
    }

    private void pageNotFound(HttpContext context)
    {
        HttpResponse response = context.Response;

        //default response where no page can be found or doesnt exist
        response.Write("<html>");
        response.Write("<body>");
        response.Write("<h1>404 Error: Page not found<h1>");
        response.Write("<h4><p>This is the default response from the HttpHandler when no page can be found</p></h4>");
        response.Write("</body>");
        response.Write("</html>");
    }

}